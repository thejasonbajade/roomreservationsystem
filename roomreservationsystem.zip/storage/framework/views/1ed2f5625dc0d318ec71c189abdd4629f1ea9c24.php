<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Dashboard</div>

                    <div class="panel-body">
                        <p>Status: <?php echo e($reservation->status); ?></p>
                        <p>Date: <?php echo e($reservation->created_at->format('M d, Y h:i A')); ?></p>
                        <form role="form" action="<?php echo e(url('/processEditReservation/'.$reservation->id)); ?>" method="GET">
                            <?php echo e(csrf_field()); ?>

                            <div id="reservationFields">
                                    <div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="room">Room</label>
                                                <select class="form-control" id="roomID[]" name="roomID[]">
                                                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                        <option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">

                                            <div class="form-group">
                                                <label for="date">Date</label>
                                                <input type="date" class="form-control" id="date[]" name="date[]" value="<?php echo e($reservation->date); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="startTime">Start Time:</label>
                                                <input type="time" class="form-control" id="startTime[]" name="startTime[]" value="<?php echo e($reservation->start_time); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="EndTime">End Time:</label>
                                                <input type="time" class="form-control" id="endTime[]" name="endTime[]" value="<?php echo e($reservation->end_time); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <input type="submit" name="submit" class="btn btn-primary" style="margin-top:25px;" value="Edit"/>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>